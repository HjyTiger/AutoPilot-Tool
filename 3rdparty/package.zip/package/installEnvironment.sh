cd ../x86
installPath=`pwd`
cd -
#install glib
xz -d -k glib-2.45.2.tar.xz 
tar -xvf glib-2.45.2.tar
cd glib-2.45.2/
./configure --with-pic --prefix=$installPath
make -j8
make install
cd ..
rm -r glib-2.45.2/
#install libffi
tar -zxvf libffi-3.2.1.tar.gz
cd libffi-3.2.1/
./configure --with-pic --prefix=$installPath
make -j8
make install
cd ..
rm -r libffi-3.2.1/
#install eigen
tar -zxvf eigen3.tar.gz 
cd eigen3/
rm -r build/
mkdir build
cd build/
cmake -DCMAKE_INSTALL_PREFIX=$installPath -fPIC ..
make install
cd ../..
rm -r eigen3/
#install lcm
tar -zxvf lcm-saic-1.3.0.tar.gz 
cd lcm-1.3.0-saic/
./configure --with-pic --prefix=$installPath
make -j8
make install
cd ..
rm -r lcm-1.3.0-saic/
#install protobuf
tar -zxvf protobuf-cpp-3.3.0.tar.gz
cd protobuf-3.3.0/
./configure --with-pic --prefix=$installPath
make -j8
make install
cd ..
rm -r protobuf-3.3.0/
cp -r kotei ../include/
#install lib3ds
unzip lib3ds-1.3.0.zip
cd lib3ds-1.3.0/
./configure --with-pic --prefix=$installPath
make -j8
make install
cd ..
rm -r lib3ds-1.3.0
#install glfw
unzip glfw-master.zip
cd glfw-master/
mkdir build
cd build/
cmake -DCMAKE_INSTALL_PREFIX=$installPath -fPIC ..
make -j8
make install
cd ../..
rm -r glfw-master



